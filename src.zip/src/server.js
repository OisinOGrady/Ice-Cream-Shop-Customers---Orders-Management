//Imported Customer Data Operations
import {customers, getCustomer, addCustomer, updateCustomerById, deleteCustomerById, addOrderToCustomer, deleteOrderFromCustomer}from './customers.js';
import express from 'express';
import cors from 'cors';
const app = express();
const PORT = 3000;


app.use(cors());
app.use(express.json());

// API Customer Operations
app.get('/customers', (req, res) => {
    const customerList = customers
    res.json(customerList.value);
})

app.get('/customers/:customerId', (req, res) => {
    const customerId = req.params.customerId;
    const customer = getCustomer(customerId);
    if (!customer) {
        res.status(404).json({ error: 'Customer not found' });
    } else {
        res.json(customer);
    }
})

app.post('/customers', (req, res) => {
    try {
    res.status(201).json(addCustomer(req.body));
  } catch (e) {
    res.status(400).json({ error: e.message });
  }
})

app.put('/customers/:customerId', (req, res) => {
    const id = Number(req.params.customerId);
  if (!getCustomer(id)) return res.status(404).json({ error: 'Customer not found' });
  try {
    updateCustomerById({ ...req.body, customerId: id });
    res.json(getCustomer(id));
  } catch (e) {
    res.status(400).json({ error: e.message });
  }
})

app.delete('/customers/:customerId', (req, res) => {
    const customerId = req.params.customerId;
    const customer = deleteCustomerById(customerId);
    if (!customer) {
        res.status(404).json({ error: 'Customer not found' });
    } else {
        res.json({ message: 'Customer deleted successfully' });
    }
})

app.put('/customers/:customerId/orders/:orderId', (req, res) => {
    const customerId = req.params.customerId;
    const orderId = req.params.orderId;
    try {
        addOrderToCustomer(customerId, orderId);
        res.json({ message: 'Order added to customer successfully' });
    } catch (error) {
        res.status(404).json({ error: error.message });
    }
})

app.delete('/customers/:customerId/orders/:orderId', (req, res) => {
    const customerId = req.params.customerId;
    const orderId = req.params.orderId;
    try {
        deleteOrderFromCustomer(customerId, orderId);
        res.json({ message: 'Order deleted from customer successfully' });
    } catch (error) {
        res.status(404).json({ error: error.message });
    }
})

app.listen(PORT, () => {
    console.log(`Server is running on http://localhost:${PORT}/customers`);
})